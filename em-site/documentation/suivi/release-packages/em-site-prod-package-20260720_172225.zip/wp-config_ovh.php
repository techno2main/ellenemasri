<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the installation.

 * You don't have to use the website, you can copy this file to "wp-config.php"

 * and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * Database settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/

 *

 * @package WordPress

 */



// ** Database settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', 'ubocrhyem26db' );



/** Database username */

define( 'DB_USER', 'ubocrhyem26db' );



/** Database password */

define( 'DB_PASSWORD', 'EMmj14phPtamdbMY' );



/** Database hostname */

define( 'DB_HOST', 'ubocrhyem26db.mysql.db' );



/** Database charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8' );



/** The database collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );



/**#@+

 * Authentication unique keys and salts.

 *

 * Change these to different unique phrases! You can generate these using

 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.

 *

 * You can change these at any point in time to invalidate all existing cookies.

 * This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'YYUIJ661JHzkg0/Th3FPfPB3amc0lO/0TmK4UapWOko4SP/oewhfWnsVGOFK' );

define( 'SECURE_AUTH_KEY',  '08EcuN9Gvrk63SsFl1ah1BQct4XNDSyqfXfbMKPwhwNvatrL/hUU8KhnnM+Z' );

define( 'LOGGED_IN_KEY',    '8aAD6vYPDs3S7vxH4Z8KHPBTBUDVRB89x6eqI9L5VpvfaGr4DW5nqP/IzgxO' );

define( 'NONCE_KEY',        'O4T6swVswLToF6Nh8GvTkEgcm/Mshrzm1vzL5ZCYhZQr1Gc5IMPT7rdzdfJy' );

define( 'AUTH_SALT',        'o/h5diI/yi7wgBwLt9OJEiBQAgDdu1RqKMEjS2xjM0tq+xObqyJUae1o9XMP' );

define( 'SECURE_AUTH_SALT', 'H3AOH8FFyFrPrZq98afJlzfEmPwrRkNwGSaF4vQWj96GWuCf0pQlnbXKnsJM' );

define( 'LOGGED_IN_SALT',   'F2H35c5MxTkEZCKdMozKGnewqvNdiCv0ssks2Qpmf8qAa3RvnscPFI0XbRyl' );

define( 'NONCE_SALT',       'ZrmI1mWraFnGO7BTHWEdN1NsVmeQWduWKf8Qf0y1GCzlw1Sk0vD6bM5ZRYDC' );



/**#@-*/



/**

 * WordPress database table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 *

 * At the installation time, database tables are created with the specified prefix.

 * Changing this value after WordPress is installed will make your site think

 * it has not been installed.

 *

 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix

 */

$table_prefix = 'wpem_';



/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/

 */

define( 'WP_DEBUG', false );
define( 'WP_DEBUG_LOG', false );
define( 'WP_DEBUG_DISPLAY', false );



/* Add any custom values between this line and the "stop editing" line. */

if ( ! defined( 'WP_HOME' ) ) {
	$em_host = $_SERVER['HTTP_HOST'] ?? 'ellenemasri.com';
	define( 'WP_HOME', 'https://' . $em_host );
}

if ( ! defined( 'WP_SITEURL' ) ) {
	define( 'WP_SITEURL', WP_HOME . '/wp' );
}







/* That's all, stop editing! Happy publishing. */



/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}



/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

